<!DOCTYPE html>
<html>
<font face="calibri,arial,times new roman" size="2">
<?php
function createnewpasswordfile($membnumber,$newpassword,$datafolder)
{
    $outputfilename = $datafolder."newpasswords.dat";
    $fp = fopen($outputfilename,"w");
    $filename = $datafolder."passwords.dat";
    $membertoupdate = 0;
// now need to check the password
// open the file and check it - password assumed to be 2nd field
      $lines = file($filename);
      foreach($lines as $line){
 // explode $line here using tab (\t) as delimiter
        $delimiter = "\t";
        $splitcontents = explode($delimiter, $line);
		  $counter = 0 ;
        foreach ( $splitcontents as $value )
		  {
			  $value = trim($value);
		     $counter = $counter + 1 ;
		     if($counter == 1)
			  {
			    fwrite($fp,"$value\t");
			    if($value == $membnumber)
			    {
					 $membertoupdate = 1;
			 	 }
			  }
		     if($counter == 2)
			  {
				 if ( $membertoupdate == 0 )
				 {
		           fwrite($fp,"$value\n");
				 }
				 if ( $membertoupdate == 1 )
				 {
	              $random = openssl_random_pseudo_bytes(18);
                 $salt = sprintf('$2y$%02d$%s',
                 13, // 2^n cost factor
                 substr(strtr(base64_encode($random), '+', '.'), 0, 22)
                 );
					  $value = trim($newpassword);
                 $crypted = crypt($value, $salt);
					  $membertoupdate = 0;
		           fwrite($fp,"$crypted\n");
				 }
			  }
		  }
	   }
      fclose($fp);
		unlink($filename);
		rename($outputfilename,$filename);
 }