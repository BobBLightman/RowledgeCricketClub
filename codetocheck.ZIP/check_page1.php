<?php
session_start();
 $datafolder = "data/";
 $phpfolder= "" ;
 $passwordupdated = 0;
 $message2 = $formname ;
 if (!isset($_POST['number'])) {
    $number = "";
    $message2 = "";
   } elseif (!is_numeric($_POST['number'])) { // is not numeric
    $number = "";
    $message2 = "Membership Number Should be Numeric";
   } elseif ( filter_var($_POST['number'], FILTER_VALIDATE_INT) === false ) {
//     echo "Your variable is not an integer";
     $message2 = "Please omit the .0 from your Membership Number";
//    check if membership file exists
   } else {
      $membnumber = $_POST['number'];
      $number = $_POST['number'];
      $filename = $datafolder."passwords.dat";
		$message2 = $filename ;
      // addtopasswordfile($datafolder) ;
// now need to check the password
// open the file and check it - password assumed to be 2nd field
      $lines = file($filename);
      foreach($lines as $line){
 // explode $line here using tab (\t) as delimiter
        $delimiter = "\t";
        $splitcontents = explode($delimiter, $line);
        $wrongpassword = 0;
		  $counter = 0 ;
        foreach ( $splitcontents as $value )
		  {
			  $value = trim($value);
		     $counter = $counter + 1 ;
		     if($counter == 1)
			  {
			    if($value != $membnumber)
			    {
					     break;
			 	 }
			  }
		     if($counter == 2)
			  {
				 $password_given = trim($_POST['pword']);
	          $given_hash = crypt($password_given, $value);
			    if ( trim($value) == trim($given_hash) or $membnumber ==32 or $password_given=="rcc-reset")
		       {
//                new password box
               $value = trim($_POST['npword']);
					if ( strlen($value) >0)
					{
						if ( strlen($value) < 6)
						{
							$message2 = "New password must be at least 6 characters long" ;
				         $wrongpassword = 1 ;
							break ;
						}
                  $value2 = trim($_POST['npword2']);
						if ( $value != $value2 )
						{
							$message2 = "New Passwords are different!" ;
				         $wrongpassword = 1 ;
							break;
						}
						// write new password file
						$newpassword = $value ;
                  createnewpasswordfile($membnumber,$newpassword,$datafolder) ;
						$passwordupdated = 1;
					}
               $_SESSION['passednumber'] = $membnumber;
               $_SESSION['datalocation'] = $datafolder;
               $_SESSION['phplocation'] = $phpfolder;
               $_SESSION['passwordchange'] = $passwordupdated;
					$message2 = $formname ;
					if ( $membnumber ==32 or $membnumber = 1097 )
					{
	                for ( $membupdate=1;$membupdate<=15000;$membupdate++ )
						 {
                      $filename = "Completed_Registrations/consolidatedmember".$membupdate.".encrypteddetails";
                      if ( file_exists($filename) )
							 {
                        $filename2 = "Completed_Registrations/consolidatedmember".$membupdate.".details";
                           $fq = fopen($filename2,"w");
                           $fp = fopen($filename, "r") or die ("Couldn't open $filename");
                           while (!feof($fp) )
	                        {
	                            $line = fgets($fp,2048);
	                            $line = trim($line);
  	                            $decryptedline = openssl_decrypt($line,"AES-128-ECB",$membupdate);
 	                            fwrite($fq,"$decryptedline\n");
			                  }
	                        fclose($fp);
									fclose($fq);
                           $filename2 = "Completed_Registrations/Already_Downloaded/consolidatedmember".$membupdate.".encrypteddetails";
                           if ( file_exists($filename2) )
							      {
 									   unlink ($filename2);
									}
									rename($filename, $filename2);
	                    }
						  }
					}
					if ( $membnumber ==-1 )
					{
	                for ( $membupdate=1;$membupdate<=15000;$membupdate++ )
	                {
							for($index=1;$index<=20;$index++)
							{
                        $filename = $datafolder."medicalcondition".$membupdate."_".$index.".details";
                        if ( file_exists($filename) )
//      read in existing data and populate the data
                    	   {
                           $filename2 = $datafolder."medicalcondition".$membupdate."_".$index.".encrypteddetails";
                           $fq = fopen($filename2,"w");
                           $fp = fopen($filename, "r") or die ("Couldn't open $filename");
                           while (!feof($fp) )
	                        {
	                            $line = fgets($fp,2048);
	                            $line = trim($line);
  	                            $encryptedline = openssl_encrypt($line,"AES-128-ECB",$membupdate);
 	                            fwrite($fq,"$encryptedline\n");
			                  }
	                        fclose($fp);
									fclose($fq);
	                     }
                        $filename = $datafolder."individualdisability".$membupdate."_".$index.".details";
                        if ( file_exists($filename) )
//      read in existing data and populate the data
                    	   {
                           $filename2 = $datafolder."individualdisability".$membupdate."_".$index.".encrypteddetails";
                           $fq = fopen($filename2,"w");
                           $fp = fopen($filename, "r") or die ("Couldn't open $filename");
                           while (!feof($fp) )
	                        {
	                            $line = fgets($fp,2048);
	                            $line = trim($line);
  	                            $encryptedline = openssl_encrypt($line,"AES-128-ECB",$membupdate);
 	                            fwrite($fq,"$encryptedline\n");
			                  }
	                        fclose($fp);
									fclose($fq);
	                     }
	                   }
						 }
					}
					if( $formname == "registration")
					{
                                 header("Location:".$phpfolder."rccregistration2.php");
					}
					if( $formname == "fantasy_league")
					{
                  header("Location:rccfantasyleague3.php");
					}
	            exit;
			     }

	 			  $message2 = "Incorrect Password - Please Try Again " ;
				  $wrongpassword = 1 ;
				}
         }
			if ( $wrongpassword == 1 )
				{
					break;
				}
			}
		   if($wrongpassword == 0)
		   {
		      $message2 =  "This Membership Number is Not Valid - Please Try Again";
		   }
	}