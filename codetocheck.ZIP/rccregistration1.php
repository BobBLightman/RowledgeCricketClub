<!DOCTYPE html>
<html>
<font face="calibri,arial,times new roman" size="3">
<style type="text/css">
h1 {color:#9400D3;}
h2 {color:#9400D3;}
h3 {color:#9400D3;}
h4 {color:#9400D3;}
h5 {color:#9400D3;}
h6 {color:#9400D3;}
p  {color:#186048;}
</style>
<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

 global $message2;
 global $membnumber;
 global $formname;
 $formname = "registration";
 include 'writenewpasswordfile.php';
 include 'check_page1.php';
 include 'addnewpasswords.php';
?>
<head>
<title>Rowledge Cricket Club Registration</title>
</head>
<body>
<table width="60%">
  <tr>
    <td>
    <h1>Welcome to Rowledge Cricket Club Online Registration 2022</h1>
    </td>
    <td align="right" valign="top">
    <img width=151 height=144 src="rcc_logo1.jpg" alt="RCC Logo">
    </td>

  </tr>
</table>
<address>
If you are interested in joining the Club, please email <a href="mailto:marketingmanager@rowledgecricketclub.com">Our Team</a> who will provide you with a login number and password
</address>



<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<p><label for="number">Membership Number:</label><br/>
<input type="text" name="number" value="<?php echo $number; ?>">
<p><label for="pword">Password:</label><br/>
<input type="password" size="25" id="pword" name="pword"/></p>
<address>
If you can't remember your password, please email <a href="mailto:marketingmanager@rowledgecricketclub.com">Our Team</a> to get it re-set (this may not be immediate)
</address>
<span style="color:red; font-size:14pt">
<?php echo $message2; ?>
</span>
<h4><?php echo "You must give your current password in the box above, but if you would like to change it to something more memorable, please give the new one in the box below"; ?></h4>
<p><label for="npword">New Password:</label>
<input type="password" size="25" id="npword" name="npword"/></p>
<h4><?php echo "New Password again, if you are changing your password"; ?></h4>
<p><label for="npword2">New Password Again:</label>
<input type="password" size="25" id="npword2" name="npword2"/></p>
<button type="submit" name="submit" value="send">Log In</button>
</form>
</body>
</font>
</html>
